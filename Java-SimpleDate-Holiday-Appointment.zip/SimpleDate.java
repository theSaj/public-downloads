package mywork.collections.ex2;
import java.util.Date;
import java.util.StringTokenizer;
public class SimpleDate {
    
	int month, day, year;
	
	private static int months[] = {31,28,31,30,31,30,31,31,30,31,30,31};
	private static String monthsByName[] = {"January", "February", "March","April","May","June","July","August","September","October","November","December"};
	
	private boolean isLeapYear;

    // constructors
    public SimpleDate(int m, int d, int y) {
        month = m;
        day = d;
        year = y;
    }

    public SimpleDate(int m, int d) {
        month = m;
        day = d;

        // need to utilize Sun's Date class to obtain
        // current year but we will store it as a 4 digit year
        Date now  = new Date();
        year = now.getYear() + 1900;
    }

    public SimpleDate(int d) {
        day = d;

        // need to utilize Sun's Date class to obtain
        // current year but we will store it as a 4 digit year
        // and current month but we will store Jan as 1 not 0
        Date now = new Date();
        year = now.getYear() + 1900;
        month = now.getMonth() + 1;
    }

    public SimpleDate() {
        // need to utilize Sun's Date class to obtain
        // current year but we will store it as a 4 digit year
        // and current month but we will store Jan as 1 not 0
        // and day of month that we will store as-is

        Date now = new Date();
        year = now.getYear() + 1900;
        month = now.getMonth() + 1;
        day = now.getDate();
    }

    public SimpleDate(String date) {
        StringTokenizer st = new StringTokenizer(date, "/");
        month = Integer.parseInt(st.nextToken());
        day = Integer.parseInt(st.nextToken());
        year = Integer.parseInt(st.nextToken());
    }

    //methods
    public int getDay()   { return day; }
    public int getMonth() { return month; }
    public int getYear()  { return year;  }
    
    public String getMonthAsString()  { return monthAsString(month);}
    public int getDayOfYear(){return dayOfYear(month,day,year);}
    public int getDaysLeftInYear(){return daysLeftInYear(month,day,year);}
    public boolean isLeapYear(){return isLeapYear(year);}
	
    
    public void setDay(int d)   { day = d; }
    public void setMonth(int m) { month = m; }
    public void setYear(int y)  { year = y; }

    public String toString() {
        return  month + "/" + day + "/" + year;
    }
    
    private String monthAsString(int month){
    	
    	return monthsByName[month-1];
    	
    }
    
    private boolean isLeapYear(int year){
    	boolean isLeapYear = (year % 4 == 0 && year % 100 != 0) || year % 400 == 0;
    	return isLeapYear;
    }
    
    private int dayOfYear(int month, int d, int year){
    	
    	int dayOfYear = 0;
    	
    	for(int i = 0; i < month-1; i++){
    		dayOfYear = dayOfYear + months[i];
    	}
    	
    	dayOfYear = (dayOfYear + d);
    	
    	
    	if(isLeapYear(year)){
    		dayOfYear = (dayOfYear + 1);
    	}
    	
    	return dayOfYear;
    }
    
    private int daysLeftInYear(int month, int d, int year){
    	
		int daysInYear = 365;
    	if(isLeapYear(year)){    		
    		daysInYear = 366;
    	}
    	
    	int daysLeftInYear = daysInYear - dayOfYear(month,d,year);
    	
    	return daysLeftInYear;
    }
    

	
}