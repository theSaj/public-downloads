/**
 * 
 */
package mywork.collections.ex2;

/**
 * @author daytime
 *
 */
public class Appointment extends SimpleDate {

	private String location;
	private String attendees;
	
	private static final String LOCATION_DEFAULT = "UNDEFINED";
	private static final String ATTENDEES_DEFAULT = "UNDEFINED";
	/**
	 * @param m
	 * @param d
	 * @param y
	 */
	public Appointment(int m, int d, int y, String l, String a) {
		//super(m, d, y);
		month = m;
        day = d;
        year = y;
        location = l;
        attendees = a;
	}
	
	public Appointment(int m, int d, int y) {
		super(m, d, y);
		location = LOCATION_DEFAULT;
		attendees = ATTENDEES_DEFAULT;
	}

	/**
	 * @param m
	 * @param d
	 */
	public Appointment(int m, int d) {
		super(m, d);
		location = LOCATION_DEFAULT;
		attendees = ATTENDEES_DEFAULT;
	}

	/**
	 * @param d
	 */
	public Appointment(int d) {
		super(d);
		location = LOCATION_DEFAULT;
		attendees = ATTENDEES_DEFAULT;
	}

	/**
	 * 
	 */
	public Appointment() {
		super();
		location = LOCATION_DEFAULT;
		attendees = ATTENDEES_DEFAULT;
	}

	/**
	 * @param date
	 */
	public Appointment(String date) {
		super(date);
		location = LOCATION_DEFAULT;
		attendees = ATTENDEES_DEFAULT;
	}
	
    public String getLocation()  { return location;  }
    
    public String getAttendees()  { return attendees;  }

}
