package mywork.collections.ex2;

//**************************************************************************************
/* AUTHOR NOTES: 
* Java implementation for the Simple Date + Holiday + Appointment exercise from "Intro to Java". 
* Intro to Java. Please note, that there are better ways to accomplish this objective.  
* 
* However, this was accomplished primarily using the basic techniques presented to that point in class.
* Initial base code provided by instructor.
* 
* - AUTHOR: Jason Epperson | jason.j.epperson
* - INSTRUCTOR: Dan Flanagan | d.flanagan@umbctraining.com
* - COURSE: Intro to Java @ UMBC Training
*/
//**************************************************************************************

public class SimpleDateTester{
	
    public static void main(String args[]){
        SimpleDate dates [] = {
		    new SimpleDate(2, 3, 2008),   //DayOfYear:34   DaysLeft:332
		    new SimpleDate(2, 3, 2011),   //DayOfYear:34   DaysLeft:331
		    new SimpleDate(3, 2, 2008),   //DayOfYear:62   DaysLeft:304
		    new SimpleDate(9, 2, 2011),   //DayOfYear:61   DaysLeft:304
		    new SimpleDate(12, 30, 2008), //DayOfYear:365  DaysLeft:1
		    new Holiday(12, 30, 2011), //DayOfYear:364  DaysLeft:1
		    new Holiday(7, 4, 2020,"4th of July"), //DayOfYear:364  DaysLeft:1
		    new Appointment(7, 4, 2020), //DayOfYear:364  DaysLeft:1
		    new Appointment(2, 13, 2020,"UMBC Training Center","Jason,Tania,Joe"),
		    new Appointment(2, 14, 2020,"UMBC Training Center","Jason,Tania,Joe"),
		    new Holiday(2, 17, 2020,"President's Day"), //DayOfYear:364  DaysLeft:1
		    new Appointment(2, 24, 2020,"System Source","Jason,Tania,Krupali") //DayOfYear:364  DaysLeft:1
		    
        };
        
        System.out.println("");
        System.out.println("**** Outputs formatted date data. " + String.format("%-64s","").replace(" ", "*"));
        System.out.println("|"+String.format("%97s","|").replace(" ", "-"));
        System.out.println("| DATE       | MONTH     | DAY# | DAYS LEFT | SPECIAL INFORMATION                                |");
        System.out.println("|"+String.format("%97s","|").replace(" ", "-"));
        for(int i = 0; i < dates.length; i++){
        	System.out.print("| ");
        	System.out.print(padString(String.format("%10s",dates[i].getDate()),11));
            System.out.print(padString("| " + dates[i].getMonthAsString(),12));
            System.out.print(padString("| " + dates[i].getDayOfYear(),7));
            System.out.print(padString("| " + dates[i].getDaysLeftInYear(),12) + "|");
            String tmpStr = "";
            if(dates[i].isLeapYear()== true){
            	tmpStr = "Leap Year";
            }
            if(dates[i].getClass().getName().equals("mywork.collections.ex2.Holiday")){
            	Holiday holiday = Holiday.class.cast(dates[i]);
            	if(tmpStr.length() > 0){
            		tmpStr = tmpStr + ", ";
            	}
            	tmpStr = tmpStr + holiday.getHoliday();
            }
            System.out.println(String.format("%-51s",tmpStr) + " |");
            if(dates[i].getClass().getName().equals("mywork.collections.ex2.Appointment")){
            	Appointment appointment = Appointment.class.cast(dates[i]);
            	tmpStr = "|"+String.format("%-7s","") + "^^^^ | Has appointment @Location:" + appointment.getLocation() + ", w/attendees: " + appointment.getAttendees();
            	System.out.print(tmpStr);
            	System.out.println(String.format("%" + (98-tmpStr.length()) + "s","|"));
            	System.out.println("|"+String.format("%97s","|").replace(" ", "-"));
            }
            
        }
        System.out.println("|"+String.format("%97s","EOF|").replace(" ", "_"));
        System.out.println("");
        
        System.out.println("**** Outputs the toString methods. " + String.format("%-63s","").replace(" ", "*"));
        for(int i = 0; i < dates.length; i++){
        	System.out.println(dates[i].toString());
        }
        System.out.println("");
        
        System.out.println("**** Outputs JSON data. " + String.format("%-74s","").replace(" ", "*"));
        for(int i = 0; i < dates.length; i++){
        	System.out.println(dates[i].toJSON());
        }
    }
    
    private static String padString(String txt2pad, int length) {
		return String.format("%-" + length + "s", txt2pad);
	}
}
