package mywork.collections.ex2;
public class SimpleDateTester{
    public static void main(String args[]){
        SimpleDate dates [] = {
		    new SimpleDate(2, 3, 2008),   //DayOfYear:34   DaysLeft:332
		    new SimpleDate(2, 3, 2011),   //DayOfYear:34   DaysLeft:331
		    new SimpleDate(3, 2, 2008),   //DayOfYear:62   DaysLeft:304
		    new SimpleDate(3, 2, 2011),   //DayOfYear:61   DaysLeft:304
		    new SimpleDate(12, 30, 2008), //DayOfYear:365  DaysLeft:1
		    new Holiday(12, 30, 2011), //DayOfYear:364  DaysLeft:1
		    new Holiday(7, 4, 2020,"4th of July"), //DayOfYear:364  DaysLeft:1
		    new Appointment(7, 4, 2020), //DayOfYear:364  DaysLeft:1
		    new Appointment(2, 13, 2020,"UMBC Training Center","Jason,Tania,Krupali"),
		    new Appointment(2, 14, 2020,"UMBC Training Center","Jason,Tania,Joe"),
		    new Holiday(2, 17, 2020,"President's Day") //DayOfYear:364  DaysLeft:1
		    
        };
        for(int i = 0; i < dates.length; i++){
        	System.out.print("| ");
        	System.out.print(padString(String.format("%10s",dates[i]),11));
            System.out.print(padString("| Month: " + dates[i].getMonthAsString(),18));
            System.out.print(padString("| Day Of Year: " + dates[i].getDayOfYear(),19));
            System.out.print(padString("| Days Left: " + dates[i].getDaysLeftInYear(),17));
            if(dates[i].isLeapYear()== true){
            	System.out.print(padString("| Leap Year ",12));
            }
            else{
            	System.out.print(padString("|",12));
            }
            if(dates[i].getClass().getName().equals("mywork.collections.ex2.Holiday")){
            	Holiday holiday = Holiday.class.cast(dates[i]);
            	System.out.print(padString("| " + holiday.getHoliday(),18));
            }
            else{
            	System.out.print(padString("|",18));
            }
            System.out.println("| ");
            if(dates[i].getClass().getName().equals("mywork.collections.ex2.Appointment")){
            	Appointment appointment = Appointment.class.cast(dates[i]);
            	String tmpStr = "|"+String.format("%-7s","") + "^^^^ | Has appointment @Location:" + appointment.getLocation() + ", w/attendees: " + appointment.getAttendees();
            	System.out.print(tmpStr);
            	System.out.println(String.format("%" + (98-tmpStr.length()) + "s","|"));
            	System.out.println("|"+String.format("%97s","|").replace(" ", "-"));
            }
            
        }
    }
    
    private static String padString(String txt2pad, int length) {
		return String.format("%-" + length + "s", txt2pad);
	}
}
