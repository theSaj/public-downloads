/**
 * 
 */
package mywork.collections.ex2;

/**
 * @author daytime
 *
 */
public class Holiday extends SimpleDate {

	String holiday;
	private static final String HOLIDAY_DEFAULT = "Holiday";
	/**
	 * @param m
	 * @param d
	 * @param y
	 */
	public Holiday(int m, int d, int y, String h) {
		//super(m, d, y);
		month = m;
        day = d;
        year = y;
        holiday = h;
	}
	
	public Holiday(int m, int d, int y) {
		super(m, d, y);
		holiday = HOLIDAY_DEFAULT;
	}

	/**
	 * @param m
	 * @param d
	 */
	public Holiday(int m, int d) {
		super(m, d);
		holiday = HOLIDAY_DEFAULT;
	}

	/**
	 * @param d
	 */
	public Holiday(int d) {
		super(d);
		holiday = HOLIDAY_DEFAULT;
	}

	/**
	 * 
	 */
	public Holiday() {
		super();
		holiday = HOLIDAY_DEFAULT;
	}

	/**
	 * @param date
	 */
	public Holiday(String date) {
		super(date);
		holiday = HOLIDAY_DEFAULT;
	}
	
    public String getHoliday()  { return holiday;  }

}
