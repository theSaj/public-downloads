package mywork.collections.ex2;

public class LeapYearCheck {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int testYear = 2000;
		boolean	isLeapYear = false;
		

		
		isLeapYear = (testYear % 4 == 0 && testYear % 100 != 0) || testYear % 400 == 0;
		System.out.println(isLeapYear);
	}

}
